@extends('layouts.barangay_layout')

@section('content')

@endsection
