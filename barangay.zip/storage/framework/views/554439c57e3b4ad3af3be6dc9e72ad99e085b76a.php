

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <div class="row">
        <?php $__currentLoopData = $officials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4" style="margin-bottom:10px;">
                <div class="card" style="width: 100%;">
                    <img src="<?php echo e(asset('storage/' . $data->user_image)); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($data->first_name); ?> <?php echo e($data->middle_name); ?> <?php echo e($data->last_anem); ?></h5>
                        <p class="card-text">Position: <?php echo e($data->position->title); ?></p>
                        <p class="card-text">Term: <?php echo e($data->office_term); ?></p>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary btn-sm float-right" data-toggle="modal"
                            data-target="#exampleModal<?php echo e($data->id); ?>">
                            View Profile
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal<?php echo e($data->id); ?>" tabindex="-1" role="dialog"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Profile</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <form action="<?php echo e(route('barangay_official_update')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for="">First Name:</label>
                                                <input type="text" required name="first_name" class="form-control"
                                                    value="<?php echo e($data->first_name); ?>">

                                                <label for="">Middle Name:</label>
                                                <input type="text" required name="middle_name" class="form-control"
                                                    value="<?php echo e($data->middle_name); ?>">

                                                <label for="">Last Name:</label>
                                                <input type="text" required name="last_name" class="form-control"
                                                    value="<?php echo e($data->last_name); ?>">

                                                <label for="">Gender:</label>
                                                <input type="text" required name="gender" class="form-control"
                                                    value="<?php echo e($data->gender); ?>">

                                                <label for="">Civil Status:</label>
                                                <input type="text" required name="civil_status" class="form-control"
                                                    value="<?php echo e($data->civil_status); ?>">

                                                <label for="">Birth Date:</label>
                                                <input type="text" required name="birth_date" class="form-control"
                                                    value="<?php echo e($data->birth_date); ?>">

                                                <label for="">Contact Number:</label>
                                                <input type="text" required name="contact_number" class="form-control"
                                                    value="<?php echo e($data->contact_number); ?>">

                                                <label for="">Spouse:</label>
                                                <input type="text" required name="spouse" class="form-control"
                                                    value="<?php echo e($data->spouse); ?>">

                                                <label for="">Office Term:</label>
                                                <input type="text" required name="office_term" class="form-control"
                                                    value="<?php echo e($data->office_term); ?>">

                                                <label for="">Position:</label>
                                                <select name="position_type_id" id="" class="form-control"
                                                    required>
                                                    <option value="<?php echo e($data->position_type_id); ?>" selected>
                                                        <?php echo e($data->position->title); ?></option>
                                                    <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($position_data->id); ?>">
                                                            <?php echo e($position_data->title); ?> Current</option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <label for="">Email:</label>
                                                <input type="text" required name="email" class="form-control"
                                                    value="<?php echo e($data->email); ?>">

                                                <input type="hidden" value="<?php echo e($data->id); ?>" name="id">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-dismiss="modal">Close</button>
                                            <button type="type" class="btn btn-success">Save changes</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.barangay_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SALAZAR-JOHN SIDNEY\Documents\GitHub\barangay\resources\views/barangay_officials_profile.blade.php ENDPATH**/ ?>