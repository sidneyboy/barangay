<?php $__env->startComponent('mail::message'); ?>
    Hello Mr/Ms: <?php echo e($first_name); ?> <?php echo e($last_name); ?>


    We are happy to tell you that you are now registered in our 
    Barangay Information and Management System.

    Here are your credentials:
    email: <?php echo e($email); ?>

    password: <?php echo e($password); ?>


    Regards,
    Management
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\SALAZAR-JOHN SIDNEY\Documents\GitHub\barangay\resources\views/send_email_to_resident.blade.php ENDPATH**/ ?>