

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="container-fluid">
        <div class="card" style="width: 100%;">
            <h6 class="card-header">Assistance Type</h6>
            <div class="card-body">
                <form action="<?php echo e(route('official_assistance_type_process')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-12">
                            <label for="">Title:</label>
                            <input type="text" class="form-control" required name="title">
                        </div>
                        <div class="col-md-12">
                            <label for="">Description:</label>
                            <input type="text" class="form-control" required name="description">
                        </div>
                        <div class="col-md-12">
                            <br />
                            <input type="hidden" value="<?php echo e($user->id); ?>" name="user_id">
                            <input type="hidden" value="<?php echo e($user->barangay_id); ?>" name="barangay_id">
                            <button type="submit" class="btn btn-sm btn-success float-right">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="card-footer">
                <div class="table table-responsive">
                    <table class="table table-bordered table-hover table-sm">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Added By</th>
                                <th>Created At</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($data->title); ?></td>
                                    <td><?php echo e($data->description); ?></td>
                                    <td><?php echo e($data->user->first_name); ?> <?php echo e($data->user->last_name); ?></td>
                                    <td><?php echo e(date('F j, Y', strtotime($data->created_at))); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.official_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SALAZAR-JOHN SIDNEY\Documents\GitHub\barangay\resources\views/official_assistance_type.blade.php ENDPATH**/ ?>