

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="card" style="width: 100%;">
        <h6 class="card-header">Resident Registration</h6>
        <div class="card-body">
            <div class="table table-responsive">
                <table class="table table-bordered table-hover table-sm">
                    <thead>
                        <tr>
                            <th>First Name</th>
                            <th>Middle Name</th>
                            <th>Last Name</th>
                            <th>Gender</th>
                            <th>Civil Status</th>
                            <th>Birth Date</th>
                            <th>Contact Number</th>
                            <th>Spouse</th>
                            <th>Mothers Name</th>
                            <th>Fathers Name</th>
                            <th>Email</th>
                            <th>Added By</th>
                            <th>Photo</th>
                            <th>Update</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $resident; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($data->first_name); ?></td>
                                <td><?php echo e($data->middle_name); ?></td>
                                <td><?php echo e($data->last_name); ?></td>
                                <td><?php echo e($data->gender); ?></td>
                                <td><?php echo e($data->civil_status); ?></td>
                                <td><?php echo e($data->birth_date); ?></td>
                                <td><?php echo e($data->contact_number); ?></td>
                                <td><?php echo e($data->spouse); ?></td>
                                <td><?php echo e($data->mothers_name); ?></td>
                                <td><?php echo e($data->fathers_name); ?></td>
                                <td><?php echo e($data->email); ?></td>
                                <td><?php echo e($data->barangay_official_id->first_name); ?><?php echo e($data->barangay_official_id->last_name); ?>

                                </td>
                                <td>
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary btn-sm btn-block" data-toggle="modal"
                                        data-target="#exampleModal<?php echo e($data->id); ?>">
                                        Photo
                                    </button>

                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal<?php echo e($data->id); ?>" tabindex="-1"
                                        role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($data->first_name); ?>

                                                        <?php echo e($data->middle_name); ?> <?php echo e($data->last_name); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="card" style="width: 100%;">
                                                        <img class="card-img-top"
                                                            src="<?php echo e(asset('/storage/' . $data->user_image)); ?>"
                                                            alt="Card image cap">
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-danger btn-sm btn-block" data-toggle="modal"
                                        data-target="#exampleModal_update<?php echo e($data->id); ?>">
                                        Update
                                    </button>

                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal_update<?php echo e($data->id); ?>" tabindex="-1"
                                        role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Profile Update</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                            <form action="<?php echo e(route('official_res_profile_update')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <label for="">First Name:</label>
                                                        <input type="text" required name="first_name"
                                                            class="form-control" value="<?php echo e($data->first_name); ?>">

                                                        <label for="">Middle Name:</label>
                                                        <input type="text" required name="middle_name"
                                                            class="form-control" value="<?php echo e($data->middle_name); ?>">

                                                        <label for="">Last Name:</label>
                                                        <input type="text" required name="last_name" class="form-control"
                                                            value="<?php echo e($data->last_name); ?>">

                                                        <label for="">Gender:</label>
                                                        <select name="gender" class="form-control" required>
                                                            <option value="<?php echo e($data->gender); ?>"><?php echo e($data->gender); ?>

                                                                Current</option>
                                                            <?php if($data->gender == 'Male'): ?>
                                                                <option value="Female">Female
                                                                </option>
                                                            <?php else: ?>
                                                                <option value="Male">Male
                                                                </option>
                                                            <?php endif; ?>
                                                        </select>

                                                        <label for="">Civil Status:</label>
                                                        <select name="civil_status" class="form-control" required>
                                                            <option value="<?php echo e($data->civil_status); ?>">
                                                                <?php echo e($data->civil_status); ?>

                                                                Current</option>
                                                            <?php if($data->civil_status == 'Single'): ?>
                                                                <option value="Married">Married
                                                                </option>
                                                            <?php else: ?>
                                                                <option value="Single">Single
                                                                </option>
                                                            <?php endif; ?>
                                                        </select>

                                                        <label for="">Birth Date:</label>
                                                        <input type="text" required name="birth_date"
                                                            class="form-control" value="<?php echo e($data->birth_date); ?>">

                                                        <label for="">Contact Number:</label>
                                                        <input type="text" required name="contact_number"
                                                            class="form-control" value="<?php echo e($data->contact_number); ?>">

                                                        <label for="">Spouse:</label>
                                                        <input type="text" required name="spouse"
                                                            class="form-control" value="<?php echo e($data->spouse); ?>">

                                                        <label for="">Mothers Name:</label>
                                                        <input type="text" required name="mothers_name"
                                                            class="form-control" value="<?php echo e($data->mothers_name); ?>">

                                                        <label for="">Fathers Name:</label>
                                                        <input type="text" required name="fathers_name"
                                                            class="form-control" value="<?php echo e($data->fathers_name); ?>">


                                                        <label for="">Email:</label>
                                                        <input type="text" required name="email"
                                                            class="form-control" value="<?php echo e($data->email); ?>">

                                                        <input type="hidden" value="<?php echo e($data->id); ?>"
                                                            name="resident_id">
                                                        <input type="hidden" value="<?php echo e($user->id); ?>"
                                                            name="user_id">
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Save
                                                            changes</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer">

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.official_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SALAZAR-JOHN SIDNEY\Documents\GitHub\barangay\resources\views/official_res_profile.blade.php ENDPATH**/ ?>