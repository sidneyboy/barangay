

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php $__currentLoopData = $assistance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <div class="card" style="width: 100%;margin-bottom:20px;">
                <h6 class="card-header">
                    <div class="row">
                        <div class="col-md-4">
                            Request No: <?php echo e($data->id); ?>

                        </div>
                        <div class="col-md-4">
                            Approved Amount: <?php echo e(number_format($data->approved_cash,2,".",",")); ?>

                        </div>
                        <div class="col-md-4">
                            <span>
                                Status: <span class="badge badge-success"><?php echo e(Str::ucfirst($data->status)); ?></span>
                            </span>
                        </div>
                    </div>
                </h6>
                <div class="card-body">
                    <h6 class="card-title">Requested By: <?php echo e($data->resident->first_name); ?>

                        <?php echo e($data->resident->middle_name); ?> <?php echo e($data->resident->last_name); ?></h6>
                    Assistance Type: <?php echo e($data->assistance->title); ?><br />
                    Brief Explanation: <?php echo e($data->explanation); ?>

                </div>
                <div class="card-footer">
                    <?php if($data->status != 'approved'): ?>
                        <span class="float-left">
                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-primary" data-toggle="modal"
                                data-target="#exampleModal<?php echo e($data->id); ?>">
                                option
                            </button>

                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal<?php echo e($data->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Approval</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <form action="<?php echo e(route('official_assistance_approved')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="">Approved Cash</label>
                                                            <input type="number" name="approved_cash" class="form-control"
                                                                required>
                                                            <input type="hidden" name="approved_by_official_id"
                                                                value="<?php echo e($user->id); ?>">
                                                            <input type="hidden" name="assistance_id"
                                                                value="<?php echo e($data->id); ?>">

                                                            <input type="hidden" name="resident_email"
                                                                value="<?php echo e($data->resident->email); ?>">

                                                            <input type="hidden" name="first_name"
                                                                value="<?php echo e($data->resident->first_name); ?>">

                                                            <input type="hidden" name="middle_name"
                                                                value="<?php echo e($data->resident->middle_name); ?>">

                                                            <input type="hidden" name="last_name"
                                                                value="<?php echo e($data->resident->last_name); ?>">

                                                            <input type="hidden" name="assistance_title"
                                                                value="<?php echo e($data->assistance->title); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-success">Save changes</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </span>
                    <?php else: ?>
                        <span class="float-left">
                            Approved Date:<?php echo e(date('F j, Y', strtotime($data->approved_date))); ?>

                        </span>
                    <?php endif; ?>
                    <span class="float-right">
                        Requested Date:<?php echo e(date('F j, Y', strtotime($data->created_at))); ?>

                    </span>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.official_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SALAZAR-JOHN SIDNEY\Documents\GitHub\barangay\resources\views/official_assistance_request.blade.php ENDPATH**/ ?>