

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="card" style="width: 100%;">
        <h6 class="card-header">Request Assistance List</h6>
        <div class="card-body">
            <div class="row">
                <?php $__currentLoopData = $assistance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12" style="margin-bottom:20px;">
                        <div class="card" style="width: 100%;">
                            <h6 class="card-header">
                                <div class="row">
                                    <div class="col-md-4">
                                        Request No: <?php echo e($data->id); ?>

                                    </div>
                                    <div class="col-md-4">
                                        Approved Amount: <?php echo e($data->approved_cash); ?>

                                    </div>
                                    <div class="col-md-4">
                                        <span>
                                            Status: <span class="badge badge-success"><?php echo e($data->status); ?></span>
                                        </span>
                                    </div>
                                </div>
                            </h6>
                            <div class="card-body">
                                <b>Assitance Type:</b> <?php echo e($data->assistance->title); ?><br />
                                <b> Brief Explanation:</b> <?php echo e($data->explanation); ?>

                            </div>
                            <div class="card-footer">
                                <span class="float-right">
                                    <?php echo e(date('F j, Y', strtotime($data->created_at))); ?>

                                </span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.resident_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SALAZAR-JOHN SIDNEY\Documents\GitHub\barangay\resources\views/res_assistance_request.blade.php ENDPATH**/ ?>