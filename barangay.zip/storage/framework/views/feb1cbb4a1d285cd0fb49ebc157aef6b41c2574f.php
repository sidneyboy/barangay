<?php echo e($slot); ?>

<?php /**PATH C:\Users\SALAZAR-JOHN SIDNEY\Documents\GitHub\barangay\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>