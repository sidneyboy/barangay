[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Users\SALAZAR-JOHN SIDNEY\Documents\GitHub\barangay\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>