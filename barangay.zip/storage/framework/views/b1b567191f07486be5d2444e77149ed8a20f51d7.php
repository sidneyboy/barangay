<?php $__env->startComponent('mail::message'); ?>
    Hello Mr/Ms: <?php echo e($first_name ." ". $middle_name ." ". $last_name); ?> 

    We are happy to inform you that your <?php echo e($assistance_title); ?>

    has been approved. Please go to our office and bring 2 valid ID.

    Regards,
    Management
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\SALAZAR-JOHN SIDNEY\Documents\GitHub\barangay\resources\views/assistance_approved_email.blade.php ENDPATH**/ ?>